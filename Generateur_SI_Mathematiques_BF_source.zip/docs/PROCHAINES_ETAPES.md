# Prochaines étapes
1. Ajouter l'appel Android au backend IA (actuellement, l'interface de départ utilise le mode hors ligne).
2. Ajouter une base locale Room pour enregistrer, rechercher, modifier et supprimer les situations.
3. Ajouter export PDF et Word.
4. Ajouter tests automatisés, validation des données et contrôle du barème.
5. Valider les situations par un enseignant avant usage.
