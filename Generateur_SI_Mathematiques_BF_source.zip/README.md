# Générateur SI Mathématiques BF
Socle de démarrage Android (Kotlin + Jetpack Compose), avec génération hors ligne par modèles, sauvegarde locale et mode IA via backend.

## Compiler
1. Installez Android Studio et le SDK Android 35.
2. Ouvrez `android/` dans Android Studio.
3. Synchronisez Gradle, puis lancez sur émulateur ou téléphone.
4. Pour l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK sera normalement dans `android/app/build/outputs/apk/debug/app-debug.apk`.

L'APK n'est pas précompilé dans cette archive : il faut compiler le projet avec Android Studio/SDK.

## IA en ligne
Configurez le backend dans `backend/README.md`. Ne mettez jamais la clé du fournisseur d'IA dans l'application Android.

## Compilation cloud avec GitHub Actions
Le dossier `.github/workflows/build-android.yml` contient un workflow de compilation cloud. Après avoir envoyé les fichiers du projet dans un dépôt GitHub, ouvrez l'onglet Actions et lancez « Construire l'APK Android ». Si la compilation réussit, téléchargez l'artefact `Generateur-SI-Mathematiques-BF-APK` depuis le résumé de l'exécution.
