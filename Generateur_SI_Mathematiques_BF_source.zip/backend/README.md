# Backend IA (prototype)
Prérequis : Node.js récent et une clé API valide auprès d'un fournisseur compatible avec `/chat/completions`.

1. `npm install`
2. Copiez `.env.example` vers `.env` et configurez les valeurs réelles.
3. `npm start`

Déployez en HTTPS pour un usage réel. Ajoutez authentification, quotas et protection contre les abus. Ne publiez jamais `.env`.
