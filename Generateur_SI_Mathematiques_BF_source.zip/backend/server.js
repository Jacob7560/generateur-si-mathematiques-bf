import express from "express";
import helmet from "helmet";
import dotenv from "dotenv";
dotenv.config();
const app = express();
app.use(helmet());
app.use(express.json({limit:"50kb"}));
app.get("/health", (_req,res)=>res.json({ok:true}));
app.post("/api/generate", async (req,res)=>{
  const {niveau,classe,notions,competence,contexte,difficulte,duree,bareme,grille}=req.body ?? {};
  if(!classe || !notions || !competence) return res.status(400).json({error:"Classe, notions et compétence sont obligatoires."});
  if(!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL)
    return res.status(503).json({error:"Service IA non configuré."});
  const system = `Tu es un concepteur de situations d'intégration en mathématiques APC/PI au Burkina Faso. Réponds en français. Construis une situation réaliste avec données numériques suffisantes, 2 à 3 consignes, corrigé détaillé et grille CM1 (pertinence), CM2 (outils), CM3 (cohérence/interprétation), CP (communication). Vérifie tous les calculs et fais totaliser la grille à ${bareme} points. Retourne uniquement du JSON : {"titre":"...","enonce":"...","consignes":["..."],"corrige":"...","grille":"..."}.`;
  try {
    const response=await fetch(`${process.env.AI_BASE_URL.replace(/\/$/,"")}/chat/completions`,{
      method:"POST",
      headers:{"Authorization":`Bearer ${process.env.AI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({model:process.env.AI_MODEL,temperature:0.3,response_format:{type:"json_object"},
        messages:[{role:"system",content:system},{role:"user",content:JSON.stringify({niveau,classe,notions,competence,contexte,difficulte,duree,bareme,grille})}]})
    });
    if(!response.ok) return res.status(502).json({error:"Erreur du fournisseur IA."});
    const data=await response.json();
    const result=JSON.parse(data.choices?.[0]?.message?.content ?? "{}");
    if(!result.enonce || !Array.isArray(result.consignes) || !result.corrige || !result.grille)
      return res.status(502).json({error:"Réponse IA incomplète."});
    res.json(result);
  } catch(e) { res.status(500).json({error:"Erreur serveur",detail:String(e)}); }
});
app.listen(Number(process.env.PORT||3000),()=>console.log("Backend started"));
